using UnityEngine;

public enum Direction
{
    forward, //+Z
    right, //+X
    back, //-Z
    left, //-X
    up, //+Y
    down //-Y

}
